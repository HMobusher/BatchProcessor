package com.bank.beans;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement( name = "accounts")
@XmlAccessorType(XmlAccessType.FIELD)
public class Accounts {
	
	@XmlElement(name = "customer")
	private List<Customer> accounts = null;
	
	public List<Customer> getAccounts() {
		return accounts;
	}
	
	public void setAccounts(List<Customer> accounts) {
		this.accounts = accounts;
	}

}
