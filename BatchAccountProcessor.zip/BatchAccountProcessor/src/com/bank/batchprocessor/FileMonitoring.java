package com.bank.batchprocessor;
import java.lang.*;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashMap;
import java.util.Map;


public class FileMonitoring {
	public static void main(String[] args) throws IOException {
		//Create an instance of WatchService Class
		try (WatchService service = FileSystems.getDefault().newWatchService()){
			
			//New Instance of the HashMap Class
			Map <WatchKey, Path> keyMap = new HashMap<>();
			//Gets the path object pointing to  where the files directory which allows to create/delete/modify them
			Path path = Paths.get("files");
			//Populate the KeyMap
			keyMap.put(path.register(service,
					StandardWatchEventKinds.ENTRY_CREATE,
					StandardWatchEventKinds.ENTRY_DELETE,
					StandardWatchEventKinds.ENTRY_MODIFY),
					path);
			//Create an instance of a class for watchkey
			WatchKey watchKey;
			
			do {
				//Reference to the watchkey
				watchKey = service.take();
				//Reference for event directory
				Path eventDir = keyMap.get(watchKey);
				//Inner Loop to loop until you get something using pollevent
				for(WatchEvent<?> event : watchKey.pollEvents()) {
					//Event Kind 
					WatchEvent.Kind<?> kind = event.kind();
					//Get the path
					Path eventPath = (Path)event.context();
					System.out.println(eventDir + ": "+ kind + ": " + eventPath);
				}
				
				//Clears the content of watchKey and notify of the event
			} while (watchKey.reset());
			
		} catch (Exception e) {
			System.out.print(e);
			
		}
		

	}

}
